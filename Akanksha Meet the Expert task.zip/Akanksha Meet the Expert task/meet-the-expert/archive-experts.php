<?php get_header(); ?>

<div class="container experts-grid">

    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post();
            $image          = get_field('expert_image');
            $designation    = get_field('designation');
            $expertise_tags = get_field('expertise_tags');

        ?>

        <div class="expert-card">
            <!-- IMAGE -->
            <img
                src="<?php echo esc_url($image['sizes']['medium']); ?>"
                srcset="<?php echo esc_attr(wp_get_attachment_image_srcset($image['ID'])); ?>"
                alt="<?php the_title(); ?>"
            >

            <!-- TITLE -->
            <h2 class="expert-tile"><?php the_title(); ?></h2>

            <!-- DESIGNATION -->
            <p class="designation"> <?php echo esc_html($designation); ?> </p>

            <!-- Expertise Tags -->
            <?php if ($expertise_tags): ?>

                <div class="expert-tags">
                    <?php
                    foreach ($expertise_tags as $term_id) {
                        $term = get_term($term_id);
                        if ($term && !is_wp_error($term)) {
                            echo '<span class="tag">' . esc_html($term->name) . '</span>';
                        }
                    }

                    ?>

                </div>

            <?php endif; ?>


            <!-- SOCIAL LINKS -->

            <div class="social-links">
                <?php
                $socials = array(

                    'facebook'  => 'social_facebook',
                    'instagram' => 'social_instagram',
                    'linkedin'  => 'social_linkedin',
                    'twitter'   => 'social_youtube'

                );

                foreach ($socials as $icon => $field) {

                    $url = get_field($field);

                    if ($url) {

                        echo '<a href="' . esc_url($url) . '" target="_blank">
                                <i class="fab fa-' . $icon . '"></i>
                              </a>';
                    }
                }

                ?>

            </div>


            <!-- QUICK VIEW BUTTON -->

            <button class="quick-view-btn" data-id="<?php the_ID(); ?>">
                Quick View
            </button>

        </div>

        <?php endwhile; ?>

    <?php endif; ?>

</div>



<!-- QUICK VIEW MODAL -->

<div id="expert-modal">
    <div class="expert-modal-overlay"></div>
    <div class="expert-modal-content">
        <span class="close-modal">&times;</span>
        <div id="expert-modal-data"></div>
    </div>
</div>

<?php get_footer(); ?>