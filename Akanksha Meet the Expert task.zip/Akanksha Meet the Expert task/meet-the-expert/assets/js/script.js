jQuery(document).ready(function ($) {
  $(".quick-view-btn").on("click", function () {
    let postID = $(this).data("id");

    $.ajax({
      url: expert_ajax.ajax_url,

      type: "POST",

      data: {
        action: "expert_quick_view",

        post_id: postID,
      },

      success: function (response) {
        $("#expert-modal-data").html(response);

        $("#expert-modal").css("display", "flex");
      },
    });
  });

  // CLOSE MODAL
  $(".close-modal, .expert-modal-overlay").on("click", function () {
    $("#expert-modal").hide();
  });
});
