<?php

// Enqueue style & Script
function oceanwp_child_assets() {

    // Parent Style
    wp_enqueue_style(
        'parent-style',
        get_template_directory_uri() . '/style.css'
    );

    // Experts Archive Assets
    if (is_post_type_archive('experts')) {

        // CSS
        wp_enqueue_style(
            'experts-css',
            get_stylesheet_directory_uri() . '/assets/css/main.css',
            array(),
            '1.0'
        );

        // JS
        wp_enqueue_script(
            'experts-js',
            get_stylesheet_directory_uri() . '/assets/js/script.js',
            array('jquery'),
            '1.0',
            true
        );

        // AJAX URL
        wp_localize_script(
            'experts-js',
            'expert_ajax',
            array(
                'ajax_url' => admin_url('admin-ajax.php')
            )
        );
    }
}
add_action('wp_enqueue_scripts', 'oceanwp_child_assets');

//  CPT Type : expert
function create_experts_cpt() {

    register_post_type('experts', array(

        'label'         => 'Experts',
        'public'        => true,
        'has_archive'   => true,
        'menu_icon'     => 'dashicons-groups',
        'supports'      => array('title', 'editor', 'thumbnail'),
        'rewrite'       => array('slug' => 'experts'),
        'show_in_rest'  => true

    ));
}
add_action('init', 'create_experts_cpt');

// Expertise taxonomy

function create_expertise_taxonomy() {

    register_taxonomy('expertise', 'experts', array(

        'label'         => 'Expertise',
        'hierarchical'  => false,
        'show_in_rest'  => true

    ));
}
add_action('init', 'create_expertise_taxonomy');


// Quick view Ajax

function expert_quick_view_callback() {

    $post_id        = $_POST['post_id'];
    $image          = get_field('expert_image', $post_id);
    $designation    = get_field('designation', $post_id);
    $expertise_tags = get_field('expertise_tags', $post_id);
    ?>

    <div class="quick-view-inner">

        <!-- IMAGE -->
        <img
            src="<?php echo esc_url($image['sizes']['large']); ?>"
            alt="<?php echo esc_attr(get_the_title($post_id)); ?>"
        >

        <!-- TITLE -->
        <h2 class="expert-tile">
            <?php echo get_the_title($post_id); ?>
        </h2>

        <!-- DESIGNATION -->

        <p class="designation"> <?php echo esc_html($designation); ?></p>

        <!-- TAGS -->
        <?php if ($expertise_tags): ?>

            <div class="expert-tags">

                <?php

                foreach ($expertise_tags as $term_id) {

                    $term = get_term($term_id);

                    if ($term && !is_wp_error($term)) {

                        echo '<span class="tag">' . esc_html($term->name) . '</span>';
                    }
                }

                ?>

            </div>

        <?php endif; ?>


        <!-- SOCIAL LINKS -->

        <div class="social-links">

            <?php
            $socials = array(
                'facebook'  => 'social_facebook',
                'instagram' => 'social_instagram',
                'linkedin'  => 'social_linkedin',
                'twitter'   => 'social_youtube'
            );

            foreach ($socials as $icon => $field) {

                $url = get_field($field, $post_id);

                if ($url) {

                    echo '<a href="' . esc_url($url) . '" target="_blank">
                            <i class="fab fa-' . $icon . '"></i>
                          </a>';
                }
            }

            ?>

        </div>
    </div>
    <?php
    wp_die();
}

add_action('wp_ajax_expert_quick_view', 'expert_quick_view_callback');
add_action('wp_ajax_nopriv_expert_quick_view', 'expert_quick_view_callback');